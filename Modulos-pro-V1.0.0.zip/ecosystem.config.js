module.exports = {
    apps: [{
      name: 'modulos-pro',
      script: 'dist/modulos-pro.js',
      instances: 'max',
      autorestart: true,
      watch: true,
      ignore_watch: ['node_modules', 'logs'],
      watch_options: {
        "followSymlinks": false
      },
      max_memory_restart: '1G',
      log_date_format: 'YYYY-MM-DD HH:mm Z',
      error_file: 'logs/err.log',
      out_file: 'logs/out.log',
      merge_logs: true,
      namespace: 'modulos-pro',
      env: {
        NODE_ENV: 'development',
        OTHER_ENV: 'other_value'
      },
      env_production: {
        NODE_ENV: 'production',
        OTHER_ENV: 'production_value'
      },
      exec_mode: 'cluster',
      cron_restart: '0 0 * * *',
    }]
};