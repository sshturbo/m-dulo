# Modulos Pro

Modulos Pro é um conjunto de módulos desenvolvidos para o Painel Web Pro, facilitando a gestão e execução de diversas tarefas automatizadas.

## Recursos

- Gestão e execução automatizada de scripts.
- Interface web para fácil interação com os módulos.
- Suporte a diversas funcionalidades customizáveis.

## Pré-requisitos

Antes de iniciar, assegure-se de ter o Node.js instalado em sua máquina. Você também precisará do npm para gerenciar as dependências do projeto.

## Instalação

Para instalar o Modulos Pro, siga estas etapas:

1. Clone o repositório para sua máquina local:

   ```bash
   git clone https://github.com/sshturbo/modulos-pro.git
   cd modulos-pro
   ```

2. Instale as dependências necessárias:

   ```bash
   npm install
   ```

3. Crie um arquivo `.env` no diretório raiz e configure as variáveis de ambiente necessárias.

   ```bash
   PORT=8040
   SCRIPTS_BASE_FOLDER=scripts
   ```

4. Inicie o servidor:

   ```bash
   npm start
   ```

## Uso

Depois de iniciar o aplicativo, você pode acessar a interface web do Modulos Pro através do navegador, utilizando o endereço `http://localhost:[PORTA]`, onde `[PORTA]` é a porta configurada no seu arquivo `.env`.

## Licença

Este projeto está sob a licença `ISC`. Veja o arquivo `LICENSE` para mais detalhes.

## Contato

- Jefferson Hipolito - [@sshturbo](https://github.com/sshturbo)
- Link do Projeto: [https://github.com/sshturbo/modulos-pro](https://github.com/sshturbo/modulos-pro)
