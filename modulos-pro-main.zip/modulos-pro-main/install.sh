#!/bin/bash

# Verificar se o Node.js está instalado
if ! command -v node &>/dev/null; then
    echo "Node.js não encontrado. Instalando v10..."
     wget -qO- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.1/install.sh
     nvm install v12.12.0
     nvm alias default v12.12.0
     nvm use v12.12.0
else
    echo "Node.js já está instalado."
fi

# Verifica se o diretório /opt/myapp/ existe
if [ -d "/opt/myapp/" ]; then
    echo "Diretório /opt/myapp/ já existe. Parando e excluindo processo do PM2 se existir..."
    
    # Parar e deletar o processo do PM2 se estiver em execução
    npx pm2 stop modulos-pro &>/dev/null
    npx pm2 delete modulos-pro &>/dev/null

    echo "Excluindo arquivos e pastas antigos..."
    sudo rm -rf /opt/myapp/
else
    echo "Diretório /opt/myapp/ não existe. Criando..."
fi

# Criar o diretório para o aplicativo
sudo mkdir -p /opt/myapp/
sudo apt install dos2unix -y

# Clonar o repositório ModulosPro
echo "Clonando modulos-pro..."
git clone https://github.com/sshturbo/modulos-pro.git /opt/myapp/

# Dar permissão de execução para scripts .sh
echo "Atualizando permissões..."
files=(
    "SshturboMakeAccount.sh"
    "ExcluirExpiradoApi.sh"
    "killuser.sh"
    "install.sh"
)

for file in "${files[@]}"; do
    sudo chmod +x /opt/myapp/"$file"
    # Converter para o formato Unix (se necessário)
    dos2unix /opt/myapp/"$file"
done

# Instalar dependências, executar build e iniciar o serviço apenas se o diretório existir e o clone for bem-sucedido
if [ -d "/opt/myapp/" ]; then
    echo "Instalando dependências do package.json..."
    cd /opt/myapp/
    npm install

    # Executar build
    echo "Executando npm run build..."
    npm run build

    # Iniciar o serviço
    npm start

    # Configurar o PM2 para iniciar na inicialização do sistema
    npx pm2 startup

    # Salvar a lista de processos do PM2
    npx pm2 save --force
else
    echo "Falha na instalação. Diretório /opt/myapp/ não encontrado."
fi
