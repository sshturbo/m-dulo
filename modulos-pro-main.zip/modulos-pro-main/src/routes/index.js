const r = s;
for (var e = s, t = a(); ; )
  try {
    if (
      443999 ==
      +parseInt(e(200)) +
        (parseInt(e(193)) / 2) * (-parseInt(e(201)) / 3) +
        parseInt(e(191)) / 4 +
        (parseInt(e(210)) / 5) * (-parseInt(e(203)) / 6) +
        (-parseInt(e(190)) / 7) * (parseInt(e(202)) / 8) +
        parseInt(e(212)) / 9 +
        -parseInt(e(195)) / 10
    )
      break;
    t.push(t.shift());
  } catch (e) {
    t.push(t.shift());
  }
function a() {
  const e = [
    "1960ONwzdg",
    "6pGDhzh",
    "/criar",
    "Router",
    "express",
    "send",
    "online",
    "/deletar",
    "1033295OzHshj",
    '\n    <!DOCTYPE html>\n    <html lang="pt-br">\n    <head>\n        <meta charset="UTF-8">\n        <meta http-equiv="X-UA-Compatible" content="IE=edge">\n        <meta name="viewport" content="width=device-width, initial-scale=1.0">\n        <title>Painel Web Pro</title>\n        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">\n        <style>\n            body {\n                font-family: Arial, sans-serif;\n                background: linear-gradient(to right, #6A82FB, #FC5C7D);\n                height: 100vh;\n                color: white;\n            }\n            .card {\n                background-color: rgba(0, 0, 0, 0.7);\n                border-radius: 20px;\n                box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);\n            }\n            img.logo {\n                width: 250px;\n                margin-bottom: 15px;\n            }\n        </style>\n    </head>\n    <body>\n        <div class="container mt-5">\n            <div class="row justify-content-center align-items-center" style="height: 80vh;">\n                <div class="col-md-6">\n                    <div class="card text-center p-4">\n                        <img src="https://i.imgur.com/p2aMFi7.png" alt="Logo" class="logo mx-auto">\n                        <h2 class="card-title mb-4">Bem-vindo ao Painel Web Pro</h2>\n                        <p class="card-text mb-3">Meus parabéns, os módulos foram instalados com sucesso!</p>\n                        <p class="card-text">Agora você pode estar criando, editando e excluindo usuários com a eficiência que só o Painel Web Pro pode oferecer.</p>\n                        <a href="https://t.me/painelprooficial" target="_blank" class="btn btn-light mt-4">Junte-se ao Grupo do Telegram</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>\n    </body>\n    </html>\n    ',
    "4607388ALgoeJ",
    "handleScriptUpload",
    "deletar",
    "editar",
    "exports",
    "../controllers/scriptController",
    "/editar",
    "post",
    "16009SblCpn",
    "2810664ETouHP",
    "/online",
    "4474eRjXKj",
    "criar",
    "7787160cShgAI",
    "editar.sh",
    "../middleware/fileCheck",
    "deletar.sh",
    ".sh",
    "779565CQeUVR",
    "6HcpJlv",
  ];
  return (a = function () {
    return e;
  })();
}
function s(e, t) {
  const n = a();
  return (s = function (e, t) {
    return (e -= 185), n[e];
  })(e, t);
}
const n = require(r(206)),
  o = require(r(187)),
  i = require(r(197)),
  l = n[r(205)]();
l.get("/", (e, t) => {
  var n = r;
  t[n(207)](n(211));
}),
  l[r(189)](r(188), i(r(196), [r(199)]), (e, t) =>
    o.handleScriptUpload(e, t, r(185), r(196))
  ),
  l[r(189)](r(209), i("deletar.sh", [r(199)]), (e, t) =>
    o.handleScriptUpload(e, t, r(214), r(198))
  ),
  l[r(189)](r(204), i(".sh"), (e, t) => o[r(213)](e, t, r(194))),
  l[r(189)](r(192), i(r(199)), (e, t) => o.handleScriptUpload(e, t, r(208))),
  (module[r(186)] = l);
