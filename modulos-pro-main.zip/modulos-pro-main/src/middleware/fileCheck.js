const n = a;
for (var t = a, e = r(); ; )
  try {
    if (
      748619 ==
      -parseInt(t(352)) * (parseInt(t(359)) / 2) +
        -parseInt(t(343)) / 3 +
        parseInt(t(351)) / 4 +
        (-parseInt(t(349)) / 5) * (parseInt(t(357)) / 6) +
        -parseInt(t(346)) / 7 +
        -parseInt(t(360)) / 8 +
        (parseInt(t(344)) / 9) * (parseInt(t(348)) / 10)
    )
      break;
    e.push(e.shift());
  } catch (n) {
    e.push(e.shift());
  }
function a(n, t) {
  const e = r();
  return (a = function (n, t) {
    return (n -= 341), e[n];
  })(n, t);
}
function r() {
  const n = [
    "Nenhum arquivo enviado",
    "split",
    "5466XykmTn",
    "size",
    "1130878CyIaCm",
    "6894688rCAafj",
    "files",
    "join",
    "Arquivo muito grande",
    "includes",
    "name",
    "2162205nNCgUG",
    "2480661ChUehb",
    "exports",
    "5615925cyipna",
    ".sh",
    "90HxtCUU",
    "55BDgIAV",
    "send",
    "4913056ykpDsB",
    "1EEIbmB",
    "Extensão de arquivo inválida. Permitido: ",
    "status",
  ];
  return (r = function () {
    return n;
  })();
}
module[n(345)] =
  (s = [n(347)]) =>
  (n, t, e) => {
    var r = a,
      n = n[r(361)] && n[r(361)].file;
    return n
      ? 10240 < n[r(358)]
        ? t[r(354)](400)[r(350)](r(363))
        : ((n = n[r(342)][r(356)](".").pop()),
          s[r(341)]("." + n)
            ? void e()
            : t[r(354)](400).send(r(353) + s[r(362)](", ")))
      : t[r(354)](400)[r(350)](r(355));
  };
