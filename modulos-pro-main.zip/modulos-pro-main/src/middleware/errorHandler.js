const a = e;
function e(r, s) {
  const t = n();
  return (e = function (r, s) {
    return (r -= 353), t[r];
  })(r, s);
}
function n() {
  const r = [
    "479754chiOjH",
    "error",
    "2007416PdmNzy",
    "47848ZVOGev",
    "Erro interno no servidor",
    "14WEmwqi",
    "402314ERCuoe",
    "666567TfIrYJ",
    "send",
    "exports",
    "191649KJcvcE",
    "397284OBwHzx",
    "145ivOpCu",
    "stack",
  ];
  return (n = function () {
    return r;
  })();
}
for (var r = e, s = n(); ; )
  try {
    if (
      180394 ==
      +parseInt(r(366)) +
        -parseInt(r(362)) / 2 +
        -parseInt(r(363)) / 3 +
        (-parseInt(r(359)) / 4) * (-parseInt(r(354)) / 5) +
        (parseInt(r(353)) / 6) * (-parseInt(r(361)) / 7) +
        parseInt(r(358)) / 8 +
        -parseInt(r(356)) / 9
    )
      break;
    s.push(s.shift());
  } catch (r) {
    s.push(s.shift());
  }
module[a(365)] = (r, s, t, e) => {
  var n = a,
    o =
      (console[n(357)]("[Error] " + r.message),
      r[n(355)] && console.error(r[n(355)]),
      r.status || 500);
  t.status(o)[n(364)]({
    error: { status: o, message: 500 === o ? n(360) : r.message },
  });
};
