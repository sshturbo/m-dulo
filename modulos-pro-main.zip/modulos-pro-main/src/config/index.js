for (var e = n, r = n, s = c(); ; )
  try {
    if (
      205124 ==
      +parseInt(r(460)) * (parseInt(r(463)) / 2) +
        (-parseInt(r(464)) / 3) * (-parseInt(r(470)) / 4) +
        (parseInt(r(465)) / 5) * (-parseInt(r(466)) / 6) +
        (-parseInt(r(469)) / 7) * (-parseInt(r(451)) / 8) +
        (parseInt(r(477)) / 9) * (parseInt(r(452)) / 10) +
        (parseInt(r(449)) / 11) * (-parseInt(r(453)) / 12) +
        (-parseInt(r(468)) / 13) * (-parseInt(r(455)) / 14)
    )
      break;
    s.push(s.shift());
  } catch (r) {
    s.push(s.shift());
  }
function n(r, e) {
  const s = c();
  return (n = function (r, e) {
    return (r -= 449), s[r];
  })(r, e);
}
require(e(472))[e(475)]();
var t = require("fs"),
  a = require(e(454)),
  o = {
    server: { port: process.env.PORT || 8040 },
    scripts: { baseFolder: process[e(474)][e(476)] || e(462) },
  },
  a = a[e(450)](__dirname, "..", "..", o.scripts[e(458)]);
try {
  t[e(473)](a) ||
    (console[e(456)](e(471) + a + e(459)),
    t[e(457)](a, { recursive: !0 }),
    console.log(e(471) + a + e(467)));
} catch (r) {
  console.error("Erro ao criar a pasta: " + r[e(461)]);
}
function c() {
  const r = [
    "message",
    "scripts",
    "2LbYrGd",
    "34377GgUwWI",
    "5kuMwLW",
    "1187520gPUoZR",
    "' criada com sucesso.",
    "25103DJLLsx",
    "24584AVUfMr",
    "120dBGEGW",
    "Pasta '",
    "dotenv",
    "existsSync",
    "env",
    "config",
    "SCRIPTS_BASE_FOLDER",
    "16308EdQeZc",
    "70169SsRbin",
    "join",
    "136jUGqUJ",
    "80tcmPVJ",
    "288YZBLEI",
    "path",
    "406MrgcBT",
    "log",
    "mkdirSync",
    "baseFolder",
    "' não encontrada. Criando...",
    "82171pDVBTC",
  ];
  return (c = function () {
    return r;
  })();
}
module.exports = o;
