const e = f;
function t() {
  const r = [
    "3dSBbqW",
    "./routes/index",
    "38lHqfKo",
    "26202hhaNXo",
    "use",
    "2140412FwlBWA",
    "1032hOFDki",
    "14110970gSFPWN",
    "port",
    "./middleware/errorHandler",
    "express-fileupload",
    "52551NwfiUB",
    "listen",
    "1342770rfEjxW",
    "express",
    "3971268fnByHY",
    "server",
    "3969135jWwrrD",
  ];
  return (t = function () {
    return r;
  })();
}
for (var r = f, n = t(); ; )
  try {
    if (
      516755 ==
      +parseInt(r(460)) * (-parseInt(r(459)) / 2) +
        (-parseInt(r(457)) / 3) * (-parseInt(r(462)) / 4) +
        parseInt(r(456)) / 5 +
        -parseInt(r(452)) / 6 +
        parseInt(r(454)) / 7 +
        (-parseInt(r(463)) / 8) * (-parseInt(r(468)) / 9) +
        -parseInt(r(464)) / 10
    )
      break;
    n.push(n.shift());
  } catch (r) {
    n.push(n.shift());
  }
const s = require(e(453)),
  o = require(e(467)),
  i = require(e(458)),
  a = require(e(466)),
  u = require("./config/index"),
  p = s();
function f(r, e) {
  const n = t();
  return (f = function (r, e) {
    return (r -= 451), n[r];
  })(r, e);
}
p.use(o()),
  p[e(461)](i),
  p[e(461)](a),
  p[e(451)](u.server[e(465)], function () {
    var r = e;
    console.log("Servidor rodando na porta " + u[r(455)][r(465)]);
  });
