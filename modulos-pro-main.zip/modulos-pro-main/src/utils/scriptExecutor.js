const a = c;
for (var r = c, e = s(); ; )
  try {
    if (
      938069 ==
      +parseInt(r(388)) * (-parseInt(r(390)) / 2) +
        parseInt(r(403)) / 3 +
        (parseInt(r(393)) / 4) * (parseInt(r(391)) / 5) +
        parseInt(r(400)) / 6 +
        -parseInt(r(396)) / 7 +
        parseInt(r(401)) / 8 +
        -parseInt(r(398)) / 9
    )
      break;
    e.push(e.shift());
  } catch (r) {
    e.push(e.shift());
  }
function c(r, e) {
  const o = s();
  return (c = function (r, e) {
    return (r -= 384), o[r];
  })(r, e);
}
const o = require("child_process")["exec"],
  i = require("fs")[a(395)],
  u = require(a(397));
function s() {
  const r = [
    "Erro ao excluir arquivos do diretório: ",
    "2290617wyWQml",
    "join",
    "map",
    "Script executado, mas não produziu saída.",
    "Erro ao executar o script: ",
    "log",
    "exports",
    "error",
    "readdir",
    "181YJAQAX",
    "dirname",
    "16138wBPHPl",
    "555455sFiiQy",
    "length",
    "4vUZwlo",
    "all",
    "promises",
    "4158406LZsdIe",
    "path",
    "1831806xyUdbm",
    "Saída do script: ",
    "10401990gegmhM",
    "4702840gxGTFu",
  ];
  return (s = function () {
    return r;
  })();
}
module[a(385)] = {
  executeScript: (n, t) => {
    o("chmod +x " + n + " && /bin/bash " + n, async (r, e, o) => {
      var s = c;
      if (r) return console[s(386)](s(407) + r.message), t(r, null);
      e || o ? console[s(384)](s(399) + e) : console[s(384)](s(406)),
        await (async (s) => {
          const n = a;
          try {
            const r = await i[n(387)](s);
            if (r[n(392)] === 4513 + -11 * -595 + 114 * -97) {
              console[n(384)]("Não há arquivos para excluir em " + s + ".");
              return;
            }
            const e = r[n(405)]((r) => {
              const e = n,
                o = u[e(404)](s, r);
              return i["unlink"](o);
            });
            await Promise[n(394)](e),
              console["log"](
                "Todos os arquivos em " + s + " foram excluídos com sucesso."
              );
          } catch (r) {
            console[n(386)](n(402) + r["message"]);
          }
        })(u[s(389)](n)),
        t(null, null);
    });
  },
};
