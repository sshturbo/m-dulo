function t() {
  const r = [
    "54015EHBUGU",
    "6293908fzkrGZ",
    "2354541Ijptdj",
    "path",
    "2118840rFpvPe",
    "readdirSync",
    "9338196RHTZyE",
    "join",
    "error",
    "2HXinHo",
    "../config",
    "6902bbVnPn",
    "baseFolder",
    "13233920xhnJSq",
    "exports",
  ];
  return (t = function () {
    return r;
  })();
}
const r = a;
for (var e = a, n = t(); ; )
  try {
    if (
      922323 ==
      -parseInt(e(195)) * (parseInt(e(208)) / 2) +
        parseInt(e(199)) / 3 +
        parseInt(e(200)) / 4 +
        -parseInt(e(203)) / 5 +
        -parseInt(e(205)) / 6 +
        -parseInt(e(201)) / 7 +
        parseInt(e(197)) / 8
    )
      break;
    n.push(n.shift());
  } catch (r) {
    n.push(n.shift());
  }
const o = require("fs"),
  s = require(r(202)),
  i = require(r(194));
s[r(206)](__dirname, "..", "..", i.scripts[r(196)]);
function a(r, e) {
  const n = t();
  return (a = function (r, e) {
    return (r -= 194), n[r];
  })(r, e);
}
module[r(198)] = {
  moveFile: (r, e, n) => {
    r.mv(e, n);
  },
  readFilesInDirectory: (e) => {
    var n = r;
    try {
      return o[n(204)](e);
    } catch (r) {
      return console[n(207)]("Erro ao ler arquivos no diretório: " + e, r), [];
    }
  },
};
