const c = s;
function s(r, e) {
  const o = a();
  return (s = function (r, e) {
    return (r -= 322), o[r];
  })(r, e);
}
for (var r = s, e = a(); ; )
  try {
    if (
      766681 ==
      +parseInt(r(348)) +
        -parseInt(r(343)) / 2 +
        parseInt(r(337)) / 3 +
        (-parseInt(r(351)) / 4) * (parseInt(r(332)) / 5) +
        parseInt(r(333)) / 6 +
        -parseInt(r(350)) / 7 +
        parseInt(r(346)) / 8
    )
      break;
    e.push(e.shift());
  } catch (r) {
    e.push(e.shift());
  }
const t = require(c(355)),
  u = require("fs"),
  l = require("../utils/fileHandler"),
  p = require(c(341)),
  o = require(c(335)),
  d = t[c(329)](__dirname, "..", "..", o[c(330)].baseFolder);
function a() {
  const r = [
    "4270832qBzAeV",
    "log",
    "message",
    "status",
    "path",
    "existsSync",
    "Erro ao salvar o arquivo: ",
    "Arquivo inválido ou muito grande.",
    "moveFile",
    "error",
    ".sh",
    "size",
    "join",
    "scripts",
    "send",
    "5FHdflV",
    "7283478mkKSWm",
    "files",
    "../config",
    "mkdirSync",
    "1613352lBbBNy",
    "Erro ao salvar o arquivo ",
    "Nome de arquivo inválido. Esperava-se ",
    "Erro ao executar o arquivo: ",
    "../utils/scriptExecutor",
    "Erro ao criar a pasta ",
    "1216638DJeBLZ",
    "exports",
    "name",
    "12268072waYeQW",
    " criada com sucesso.",
    "338776IDjLvz",
    "executeScript",
    "8268918GfiBHy",
  ];
  return (a = function () {
    return r;
  })();
}
module[c(344)] = {
  handleScriptUpload: (e, o, r, s) => {
    const i = c,
      a = e[i(334)].file;
    if (!a) return o[i(354)](400)[i(331)]("Nenhum arquivo enviado");
    if (!a.name.endsWith(i(327)) || 10485760 < a[i(328)])
      return o[i(354)](400)[i(331)](i(324));
    if (s && a[i(345)] !== s) return o.status(400)[i(331)](i(339) + s + ".");
    e = t.join(d, r);
    if (!u[i(322)](e))
      try {
        u[i(336)](e, { recursive: !0, mode: 493 }),
          console[i(352)]("Pasta " + e + i(347));
      } catch (r) {
        return (
          console.error(i(342) + e + ": " + r),
          o[i(354)](500)[i(331)]("Erro ao criar a pasta de destino: " + r)
        );
      }
    const n = t[i(329)](e, a.name);
    l[i(325)](a, n, (r) => {
      var e = i;
      if (r)
        return (
          console[e(326)](e(338) + n + ": " + r),
          o.status(500)[e(331)](e(323) + r)
        );
      o.status(200)[e(331)]("A sincronização foi iniciada com sucesso!");
      {
        var s = n,
          a = null;
        const t = c;
        p[t(349)](s, (r, e) => {
          var o = t;
          r
            ? (console[o(326)](
                "Erro ao executar o script " + s + ": " + r[o(353)]
              ),
              a && a[o(354)](500)[o(331)](o(340) + r.message))
            : (console[o(352)]("Script executado com sucesso: " + e),
              a && a[o(354)](200)[o(331)]("Script executado com sucesso!"));
        });
      }
    });
  },
};
